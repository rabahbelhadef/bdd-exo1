create definer = root@`%` event vider_pannier
  on schedule
    every '1' MINUTE
      starts '2020-09-21 10:45:52'
  enable
do
  BEGIN
	    DELETE FROM etudiant5  WHERE date_creation < CURRENT_TIMESTAMP() - INTERVAL 1 MINUTE;
	END;

